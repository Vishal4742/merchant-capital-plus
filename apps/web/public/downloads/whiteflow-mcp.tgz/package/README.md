# whiteflow-mcp

Whiteflow Merchant MCP server over stdio. Run: `npx -y https://whiteflow.org/downloads/whiteflow-mcp.tgz`.
Sandbox by default (no key, no network). For testnet set `WHITEFLOW_MODE=testnet` and `WHITEFLOW_API_KEY=sk_test_...`.
Source: https://github.com/Vishal4742/whiteflow/tree/main/packages/mcp
