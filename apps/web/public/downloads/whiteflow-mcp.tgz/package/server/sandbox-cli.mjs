#!/usr/bin/env node
import { createRequire as __wfRequire } from "node:module";
const require = __wfRequire(import.meta.url);

// src/money.ts
var DIGITS = { USDT: 6, USD: 2, EUR: 2, GBP: 2, INR: 2, AED: 2, SGD: 2 };
var SYMBOL = { INR: "₹", USD: "$", EUR: "€", GBP: "£" };
var MAX_INTEGER_DIGITS = 12;
var DECIMAL = /^(\d+)(?:\.(\d+))?$/;
var GROUPED = /^\d{1,3}(,\d{3})+(\.\d+)?$/;
var MoneyError = class extends Error {
};
function parseMoney(text, currency, name = "amount", { allowZero = false } = {}) {
  if (typeof text !== "string") throw new MoneyError(`${name} must be a decimal string like "25.00".`);
  const trimmed = text.trim();
  if (trimmed.includes(",") && !GROUPED.test(trimmed)) throw new MoneyError(`${name} must use a dot for decimals, like "1.50"; commas only between thousands.`);
  const match = DECIMAL.exec(trimmed.replaceAll(",", ""));
  if (!match) throw new MoneyError(`${name} must be a positive decimal like "25.00" (digits and one dot; no sign, no symbol).`);
  const [, whole, fraction = ""] = match;
  const digits = DIGITS[currency];
  if (fraction.length > digits) throw new MoneyError(`${name} has ${fraction.length} decimals, but ${currency} has ${digits}. Give it like "${example(currency)}".`);
  if (whole.length > MAX_INTEGER_DIGITS) throw new MoneyError(`${name} is too large.`);
  const units = BigInt(whole) * 10n ** BigInt(digits) + BigInt(fraction.padEnd(digits, "0") || "0");
  if (units === 0n && !allowZero) throw new MoneyError(`${name} must be more than 0.`);
  return { currency, units };
}
var example = (currency) => DIGITS[currency] === 2 ? "2000.00" : "25.50";
function decimal(units, currency) {
  const digits = DIGITS[currency], negative = units < 0n, abs = negative ? -units : units;
  const scale = 10n ** BigInt(digits);
  let fraction = (abs % scale).toString().padStart(digits, "0");
  while (fraction.length > 2 && fraction.endsWith("0")) fraction = fraction.slice(0, -1);
  return `${negative ? "-" : ""}${abs / scale}${digits ? `.${fraction}` : ""}`;
}
function display(units, currency) {
  const [whole, fraction] = decimal(units, currency).split(".");
  const grouped = whole.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  const text = fraction ? `${grouped}.${fraction}` : grouped;
  return SYMBOL[currency] ? `${SYMBOL[currency]}${text}` : `${text} ${currency}`;
}

// src/dates.ts
function validZone(zone) {
  if (typeof zone !== "string" || !zone || zone.length > 64) return false;
  try {
    new Intl.DateTimeFormat("en-US", { timeZone: zone });
    return true;
  } catch {
    return false;
  }
}
var dateIn = (ms, zone) => new Intl.DateTimeFormat("en-CA", { timeZone: zone, year: "numeric", month: "2-digit", day: "2-digit" }).format(ms);

// src/sandbox/store.ts
import { createHash, randomBytes as randomBytes2 } from "node:crypto";
import { existsSync as existsSync2, mkdirSync as mkdirSync2, readFileSync as readFileSync2, writeFileSync as writeFileSync2 } from "node:fs";
import { homedir } from "node:os";
import { join } from "node:path";

// src/state.ts
import { randomBytes } from "node:crypto";
import { closeSync, existsSync, mkdirSync, openSync, readFileSync, renameSync, rmSync, statSync, writeFileSync, writeSync } from "node:fs";
import { dirname } from "node:path";
var LOCK_WAIT_MS = 5e3;
var STALE_LOCK_MS = 3e4;
var sleepSync = (ms) => Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms);
var StateError = class extends Error {
  expose = true;
};
function lock(file) {
  const path = `${file}.lock`;
  const deadline = Date.now() + LOCK_WAIT_MS;
  const token = `${process.pid}:${randomBytes(8).toString("hex")}`;
  for (; ; ) {
    try {
      const fd = openSync(path, "wx", 384);
      writeSync(fd, token);
      closeSync(fd);
      return () => {
        try {
          if (readFileSync(path, "utf8") === token) rmSync(path, { force: true });
        } catch {
        }
      };
    } catch (error) {
      if (error.code !== "EEXIST") throw error;
      try {
        if (Date.now() - statSync(path).mtimeMs > STALE_LOCK_MS) rmSync(path, { force: true });
      } catch {
      }
      if (Date.now() > deadline) throw new StateError(`${file} is locked by another Whiteflow process. Try again in a moment.`);
      sleepSync(25);
    }
  }
}
function read(file, initial) {
  if (!existsSync(file)) return initial();
  try {
    return JSON.parse(readFileSync(file, "utf8"));
  } catch {
    throw new StateError(`${file} is damaged (not valid JSON). Move it aside to start fresh; nothing was changed.`);
  }
}
function write(file, value) {
  const temp = `${file}.${process.pid}.${randomBytes(6).toString("hex")}.tmp`;
  writeFileSync(temp, JSON.stringify(value, null, 2), { mode: 384 });
  for (let tries = 0; ; tries++) {
    try {
      renameSync(temp, file);
      return;
    } catch (error) {
      if (tries >= 20 || !["EPERM", "EBUSY", "EACCES"].includes(error.code ?? "")) throw error;
      sleepSync(25);
    }
  }
}
function transact(file, initial, change2) {
  mkdirSync(dirname(file), { recursive: true, mode: 448 });
  const release = lock(file);
  try {
    const { next, result } = change2(read(file, initial));
    if (next !== void 0) write(file, next);
    return result;
  } finally {
    release();
  }
}
var snapshot = (file, initial) => transact(file, initial, (state) => ({ result: state }));

// src/sandbox/store.ts
var ALL_SCOPES = ["account:read", "customers:read", "customers:write", "links:read", "links:write", "invoices:read", "invoices:write", "payments:read", "reports:read"];
var SANDBOX_KEY = /^wf_sbx_[A-Za-z0-9_-]{32}$/;
var sha256 = (text) => createHash("sha256").update(text).digest("hex");
var newId = (prefix) => `${prefix}_${randomBytes2(12).toString("base64url")}`;
var newSandboxKey = () => `wf_sbx_${randomBytes2(24).toString("base64url")}`;
function defaultStateDir(env = process.env) {
  if (env.WHITEFLOW_STATE_DIR) return env.WHITEFLOW_STATE_DIR;
  const base = process.platform === "win32" && env.APPDATA ? env.APPDATA : env.XDG_CONFIG_HOME || join(homedir(), ".config");
  return join(base, "whiteflow-mcp");
}
var stateFile = (dir) => join(dir, "sandbox.json");
var credentialsFile = (dir) => join(dir, "sandbox-credentials.json");
var empty = () => ({
  version: 1,
  created_at: Date.now(),
  webhook_secret: randomBytes2(32).toString("hex"),
  merchants: [],
  keys: [],
  customers: [],
  links: [],
  invoices: [],
  payments: [],
  approvals: [],
  idempotency: [],
  processed_events: [],
  event_log: []
});
var current = (state) => ({
  ...state,
  approvals: state.approvals ?? [],
  merchants: state.merchants.map((m) => ({ ...m, publish_policy: m.publish_policy ?? "owner_approval" })),
  invoices: state.invoices.map((i) => ({ ...i, revision: i.revision ?? 1 }))
});
var read2 = (dir) => current(snapshot(stateFile(dir), empty));
var change = (dir, fn) => transact(stateFile(dir), empty, (state) => fn(current(state)));
function addMerchant(dir, opts) {
  const apiKey = newSandboxKey(), merchantId = newId("mer"), keyId = newId("key");
  change(dir, (state) => ({
    next: {
      ...state,
      merchants: [...state.merchants, { id: merchantId, name: opts.name, timezone: opts.timezone, next_number: 1001, publish_policy: "owner_approval" }],
      keys: [...state.keys, { id: keyId, merchant_id: merchantId, hash: sha256(apiKey), label: "sandbox", scopes: opts.scopes ?? ALL_SCOPES, expires_at: opts.expiresAt ?? null, revoked_at: null }]
    },
    result: void 0
  }));
  return { merchantId, apiKey, keyId };
}
function ensureSandbox(dir, timezone) {
  mkdirSync2(dir, { recursive: true, mode: 448 });
  const file = credentialsFile(dir);
  if (existsSync2(file) && existsSync2(stateFile(dir))) {
    let saved;
    try {
      saved = JSON.parse(readFileSync2(file, "utf8"));
    } catch {
      throw new Error(`${file} is damaged. Delete it and the sandbox folder to start a fresh sandbox.`);
    }
    if (saved.api_key && SANDBOX_KEY.test(saved.api_key)) return { apiKey: saved.api_key, created: false };
  }
  const { apiKey } = addMerchant(dir, { name: "Demo Business (sandbox)", timezone });
  writeFileSync2(file, JSON.stringify({ api_key: apiKey, note: "Sandbox only: a simulated key for the local Whiteflow simulator. It works nowhere else." }, null, 2), { mode: 384 });
  return { apiKey, created: true };
}

// ../sdk/index.ts
import { createHmac, randomUUID, timingSafeEqual } from "node:crypto";
var WebhookSignatureError = class extends Error {
  constructor(message) {
    super(message);
    this.name = "WebhookSignatureError";
  }
};
var SIGNATURE_HEADER = "MC-Signature";
var DEFAULT_TOLERANCE_SEC = 300;
var hmac = (secret, timestamp, rawBody) => createHmac("sha256", secret).update(`${timestamp}.`).update(rawBody).digest();
function signWebhook(rawBody, secret, timestamp = Math.floor(Date.now() / 1e3)) {
  if (!secret) throw new Error("signWebhook needs the endpoint's webhook secret.");
  return `t=${timestamp},v1=${hmac(secret, timestamp, rawBody).toString("hex")}`;
}
function constructEvent(rawBody, header, secret, opts = {}) {
  if (!secret) throw new Error("No webhook secret configured: set the signing secret shown for your endpoint.");
  const tolerance = opts.toleranceSec ?? DEFAULT_TOLERANCE_SEC;
  if (!Number.isFinite(tolerance) || tolerance < 0) throw new Error("toleranceSec must be a finite number of seconds, 0 or more.");
  const parts = new Map((header ?? "").split(",").map((part) => part.trim().split("=", 2)));
  const t = parts.get("t") ?? "", v1 = parts.get("v1") ?? "";
  if (!/^\d{1,12}$/.test(t) || !/^[0-9a-f]{64}$/.test(v1)) throw new WebhookSignatureError(`Missing or malformed ${SIGNATURE_HEADER} header.`);
  const timestamp = Number(t);
  if (!(Math.abs(Math.floor(Date.now() / 1e3) - timestamp) <= tolerance)) {
    throw new WebhookSignatureError("Webhook timestamp is outside the tolerance window (possible replay).");
  }
  if (!timingSafeEqual(hmac(secret, timestamp, rawBody), Buffer.from(v1, "hex"))) {
    throw new WebhookSignatureError("Webhook signature doesn't match: check the secret, and pass the raw body, not re-serialized JSON.");
  }
  const text = typeof rawBody === "string" ? rawBody : new TextDecoder().decode(rawBody);
  return JSON.parse(text);
}

// src/sandbox/provider.ts
var MAX_LOG = 200;
var MAX_EVENT_IDS = 1e4;
var TYPES = { "payment.pending": "pending", "payment.succeeded": "succeeded", "payment.failed": "failed" };
var log = (state, entry2) => ({ ...state, event_log: [...state.event_log, entry2].slice(-MAX_LOG) });
function valid(event) {
  const e = event;
  const d = e?.data;
  return !!e && typeof e.id === "string" && /^evt_[\w-]{8,64}$/.test(e.id) && typeof e.type === "string" && e.type in TYPES && !!d && /^pay_[\w-]{8,64}$/.test(d.payment_id) && typeof d.merchant_id === "string" && /^\d{1,15}$/.test(d.amount) && d.amount !== "0" && d.currency === "USDT" && Number.isSafeInteger(d.sequence) && d.sequence > 0 && (d.target?.kind === "invoice" || d.target?.kind === "link") && typeof d.target.id === "string";
}
function credit(invoice, amount, now) {
  const paid = BigInt(invoice.amount_paid) + amount;
  const complete = paid >= BigInt(invoice.total);
  return { ...invoice, amount_paid: paid.toString(), status: complete ? "paid" : invoice.status, paid_at: complete ? invoice.paid_at ?? now : invoice.paid_at };
}
function processEvent(dir, raw, header, now = Date.now()) {
  return change(dir, (state) => {
    const reject = (id2, type2, reason2) => ({ next: log(state, { id: id2, type: type2, at: now, outcome: "rejected", reason: reason2 }), result: { event_id: id2, type: type2, outcome: "rejected", reason: reason2 } });
    let event;
    try {
      event = constructEvent(raw, header, state.webhook_secret, { toleranceSec: 300 });
    } catch (error) {
      return reject("(unverified)", "(unverified)", `signature check failed: ${error.message}`);
    }
    if (!valid(event)) return reject("(invalid)", "(invalid)", "the event's fields are missing or malformed");
    const { id, type, data } = event;
    if (state.processed_events.includes(id)) {
      return { next: log(state, { id, type, at: now, outcome: "duplicate", reason: "already processed" }), result: { event_id: id, type, outcome: "duplicate", reason: "already processed: applied once only" } };
    }
    const seen = { ...state, processed_events: [...state.processed_events, id].slice(-MAX_EVENT_IDS) };
    const target = data.target.kind === "invoice" ? seen.invoices.find((i) => i.id === data.target.id && i.merchant_id === data.merchant_id) : seen.links.find((l) => l.id === data.target.id && l.merchant_id === data.merchant_id);
    if (!target) return reject(id, type, "unknown merchant or target");
    const status = TYPES[type];
    const prior = seen.payments.find((p) => p.id === data.payment_id);
    if (prior && (prior.merchant_id !== data.merchant_id || prior.target.id !== data.target.id || prior.amount !== data.amount)) return reject(id, type, "event disagrees with the recorded payment");
    if (prior && (data.sequence <= prior.sequence || prior.status !== "pending")) {
      const reason2 = prior.status !== "pending" ? `payment is already ${prior.status}; a late ${status} can't change it` : `older than the state already applied (sequence ${data.sequence} ≤ ${prior.sequence})`;
      return { next: log(seen, { id, type, at: now, outcome: "stale", reason: reason2 }), result: { event_id: id, type, outcome: "stale", reason: reason2 } };
    }
    const payment = prior ? { ...prior, status, sequence: data.sequence, succeeded_at: status === "succeeded" ? now : null } : { id: data.payment_id, merchant_id: data.merchant_id, target: data.target, amount: data.amount, currency: "USDT", status, sequence: data.sequence, created_at: now, succeeded_at: status === "succeeded" ? now : null, provider_ref: data.provider_ref };
    let next = { ...seen, payments: prior ? seen.payments.map((p) => p.id === payment.id ? payment : p) : [...seen.payments, payment] };
    let reason = `payment ${status}`;
    if (status === "succeeded" && data.target.kind === "invoice") {
      const invoice = target;
      if (invoice.status === "draft") {
        reason = "payment recorded, but the invoice is a draft: it was not credited (reconcile reports it)";
      } else {
        const credited = credit(invoice, BigInt(data.amount), now);
        next = { ...next, invoices: next.invoices.map((i) => i.id === invoice.id ? credited : i) };
        const due = BigInt(credited.total) - BigInt(credited.amount_paid);
        reason = due > 0n ? `underpaid: ${display(due, "USDT")} still due` : due < 0n ? `overpaid by ${display(-due, "USDT")}` : "invoice paid in full";
      }
    }
    return { next: log(next, { id, type, at: now, outcome: "applied", reason }), result: { event_id: id, type, outcome: "applied", reason } };
  });
}
function simulatePayment(dir, ref, opts = {}, now = Date.now) {
  const { target, merchantId, amount } = change(dir, (state) => ({ result: resolve(state, ref, opts.amountUnits) }));
  const secret = change(dir, (state) => ({ result: state.webhook_secret }));
  const paymentId = newId("pay"), providerRef = newId("sbxref");
  const make = (type, sequence) => ({
    id: newId("evt"),
    type,
    created: Math.floor(now() / 1e3),
    data: { payment_id: paymentId, merchant_id: merchantId, target, amount: amount.toString(), currency: "USDT", sequence, provider_ref: providerRef }
  });
  const pending = make("payment.pending", 1), final = make(opts.scenario === "fail" ? "payment.failed" : "payment.succeeded", 2);
  const order = opts.scenario === "out-of-order" ? [final, pending] : opts.scenario === "duplicate" ? [pending, final, final] : [pending, final];
  const deliveries = order.map((event) => {
    const raw = JSON.stringify(event);
    const header = signWebhook(raw, opts.scenario === "bad-signature" ? `${secret}-wrong` : secret);
    return processEvent(dir, raw, header, now());
  });
  return { payment_id: paymentId, amount: decimal(amount, "USDT"), deliveries };
}
function resolve(state, ref, override) {
  const upper = ref.toUpperCase();
  const invoices = state.invoices.filter((i) => i.id === ref || i.number === upper);
  const links = state.links.filter((l) => l.id === ref || l.slug === ref);
  if (invoices.length + links.length === 0) throw new Error(`No sandbox invoice or link matches ${ref}.`);
  if (invoices.length + links.length > 1) throw new Error(`${ref} matches more than one sandbox record (several merchants); use its id instead.`);
  if (override !== void 0 && override <= 0n) throw new Error("The amount must be more than 0.");
  if (invoices.length) {
    const invoice = invoices[0];
    if (invoice.status === "draft") throw new Error(`${invoice.id} is a draft: finalize it first (a customer can't pay a draft).`);
    const due = BigInt(invoice.total) - BigInt(invoice.amount_paid);
    const amount = override ?? due;
    if (amount <= 0n) throw new Error(`${invoice.number} has nothing left to pay; pass an amount to simulate an overpayment.`);
    return { target: { kind: "invoice", id: invoice.id }, merchantId: invoice.merchant_id, amount };
  }
  const link = links[0];
  if (override !== void 0) return { target: { kind: "link", id: link.id }, merchantId: link.merchant_id, amount: override };
  if (link.amount === null) throw new Error("This link lets the payer choose the amount: pass --amount (USDT).");
  if (link.currency === "USDT") return { target: { kind: "link", id: link.id }, merchantId: link.merchant_id, amount: BigInt(link.amount) };
  if (link.currency === "USD") return { target: { kind: "link", id: link.id }, merchantId: link.merchant_id, amount: BigInt(link.amount) * 10000n };
  throw new Error(`This link is priced in ${link.currency}; the sandbox has no exchange rates, so pass the USDT amount the customer pays with --amount.`);
}
function reconcile(dir, now = Date.now()) {
  return change(dir, (state) => {
    const drift = [];
    const invoices = state.invoices.map((invoice) => {
      if (invoice.status === "draft") return invoice;
      const verified = state.payments.filter((p) => p.status === "succeeded" && p.target.kind === "invoice" && p.target.id === invoice.id).reduce((sum, p) => sum + BigInt(p.amount), 0n);
      if (verified === BigInt(invoice.amount_paid)) return invoice;
      drift.push({ invoice: invoice.number ?? invoice.id, recorded: decimal(BigInt(invoice.amount_paid), "USDT"), verified: decimal(verified, "USDT") });
      const complete = verified >= BigInt(invoice.total);
      return { ...invoice, amount_paid: verified.toString(), status: complete ? "paid" : "open", paid_at: complete ? invoice.paid_at ?? now : null };
    });
    return { next: drift.length ? { ...state, invoices } : void 0, result: { checked: invoices.length, drift } };
  });
}

// src/journal.ts
var SERVER_RETENTION_MS = 24 * 60 * 6e4;
var RESUME_LIMIT_MS = SERVER_RETENTION_MS - 60 * 6e4;
var REPLAY_WINDOW_MS = 15 * 6e4;
function canonical(value) {
  const sort = (v) => Array.isArray(v) ? v.map(sort) : v && typeof v === "object" ? Object.fromEntries(Object.keys(v).sort().map((k) => [k, sort(v[k])])) : v;
  return JSON.stringify(sort(value));
}

// src/sandbox/records.ts
var SANDBOX_BASE = "https://sandbox.whiteflow.invalid";
var APPROVAL_TTL_MS = 48 * 60 * 6e4;
var SandboxHttpError = class extends Error {
  status;
  extra;
  constructor(status, message, extra = {}) {
    super(message);
    this.status = status;
    this.extra = extra;
  }
};
var iso = (ms) => ms === null ? null : new Date(ms).toISOString();
var today = (merchant, now) => dateIn(now, merchant.timezone);
var contentHash = (i) => sha256(canonical({ customer_id: i.customer_id, currency: i.currency, line_items: i.line_items, subtotal: i.subtotal, discount: i.discount, tax: i.tax, total: i.total, memo: i.memo, due_date: i.due_date }));
function approvalJson(approval, now) {
  const status = approval.status === "pending" && approval.expires_at <= now ? "expired" : approval.status;
  return {
    id: approval.id,
    invoice_id: approval.invoice_id,
    revision: approval.revision,
    status,
    total: decimal(BigInt(approval.total), approval.currency),
    currency: approval.currency,
    customer_id: approval.customer_id,
    requested_at: iso(approval.requested_at),
    expires_at: iso(approval.expires_at),
    decided_at: iso(approval.decided_at),
    review_url: `${SANDBOX_BASE}/review/${approval.id}`
  };
}
function decide(state, approvalId, decision, now) {
  const approval = state.approvals.find((a) => a.id === approvalId);
  if (!approval) throw new Error(`No sandbox approval ${approvalId}.`);
  const view = approvalJson(approval, now);
  if (view.status !== "pending") throw new Error(`Approval ${approvalId} is ${view.status}; it can't be decided (again).`);
  const invoice = state.invoices.find((i) => i.id === approval.invoice_id);
  const decided = (status) => state.approvals.map((a) => a.id === approvalId ? { ...a, status, decided_at: now } : a);
  if (decision === "reject") return { next: { ...state, approvals: decided("rejected") }, outcome: "rejected" };
  if (invoice.status !== "draft" || invoice.revision !== approval.revision || contentHash(invoice) !== approval.hash || invoice.total !== approval.total) {
    return { next: { ...state, approvals: decided("superseded") }, outcome: "superseded" };
  }
  const merchant = state.merchants.find((m) => m.id === invoice.merchant_id);
  const { invoice: open, merchant: numbered } = finalized(merchant, invoice, now);
  return {
    next: {
      ...state,
      approvals: decided("approved"),
      invoices: state.invoices.map((i) => i.id === open.id ? open : i),
      merchants: state.merchants.map((m) => m.id === numbered.id ? numbered : m)
    },
    outcome: "approved"
  };
}
function finalized(merchant, invoice, now) {
  if (invoice.status !== "draft") throw new SandboxHttpError(409, `Invoice ${invoice.number} is already ${invoice.status}; only a draft can be finalized.`);
  const local = today(merchant, now);
  if (invoice.due_date < local) throw new SandboxHttpError(422, `This draft's due date ${invoice.due_date} has passed (today is ${local}). Create a new draft with a later due date.`);
  return {
    invoice: { ...invoice, status: "open", number: `WF-${merchant.next_number}`, finalized_at: now },
    merchant: { ...merchant, next_number: merchant.next_number + 1 }
  };
}

// src/sandbox/cli.ts
var SCENARIOS = ["normal", "duplicate", "out-of-order", "bad-signature", "fail"];
function option(args, name) {
  const i = args.indexOf(`--${name}`);
  return i >= 0 ? args[i + 1] : void 0;
}
function run(argv, env, out, now = Date.now) {
  const [command, ...args] = argv;
  const dir = defaultStateDir(env);
  const zone = option(args, "timezone") ?? env.WHITEFLOW_TIMEZONE ?? "UTC";
  if (!validZone(zone)) throw new Error(`--timezone must be an IANA zone like Asia/Kolkata (got ${zone}).`);
  switch (command) {
    case "init": {
      const { created } = ensureSandbox(dir, zone);
      out(`${created ? "Created" : "Found"} the Whiteflow sandbox in ${dir} (simulated data only; no real money, no network).`);
      return 0;
    }
    case "pay": {
      const ref = args.find((a, i) => !a.startsWith("--") && !args[i - 1]?.startsWith("--"));
      if (!ref) throw new Error("Usage: whiteflow-sandbox pay <WF-1001 | inv_… | lnk_… | slug> [--amount 12.50] [--scenario …]");
      const scenario = option(args, "scenario") ?? "normal";
      if (!SCENARIOS.includes(scenario)) throw new Error(`--scenario must be one of ${SCENARIOS.join(", ")}.`);
      const amountText = option(args, "amount");
      const amountUnits = amountText === void 0 ? void 0 : parseMoney(amountText, "USDT", "--amount").units;
      const result = simulatePayment(dir, ref, { amountUnits, scenario });
      out(`SANDBOX: simulated payment ${result.payment_id} of ${result.amount} USDT for ${ref} (${scenario}). Signed provider events:`);
      for (const d of result.deliveries) out(`  ${d.type.padEnd(18)} ${d.outcome.padEnd(9)} ${d.reason}`);
      return 0;
    }
    case "approve":
    case "reject": {
      const id = args.find((a) => /^apr_[\w-]{1,40}$/.test(a));
      if (!id) throw new Error(`Usage: whiteflow-sandbox ${command} <apr_…> (the id from finalize_invoice's result)`);
      const outcome = change(dir, (state) => {
        const { next, outcome: outcome2 } = decide(state, id, command, now());
        return { next, result: outcome2 };
      });
      const said = { approved: "approved: the invoice is published (open) with its number and payment URL", rejected: "rejected: the invoice stays a draft", superseded: "not applied: the draft changed after the request, so this approval no longer matches it" };
      out(`SANDBOX Owner decision on ${id}: ${said[outcome] ?? outcome}.`);
      return outcome === "superseded" ? 1 : 0;
    }
    case "reconcile": {
      const { checked, drift } = reconcile(dir);
      out(`Reconciled ${checked} invoice(s) against verified payments: ${drift.length ? `${drift.length} corrected` : "no drift"}.`);
      for (const d of drift) out(`  ${d.invoice}: recorded ${d.recorded}, verified ${d.verified} (fixed)`);
      return 0;
    }
    case "status": {
      const s = read2(dir);
      out(`Whiteflow sandbox in ${dir}: ${s.merchants.length} merchant(s), ${s.customers.length} customer(s), ${s.links.length} link(s), ${s.invoices.length} invoice(s), ${s.payments.length} payment(s).`);
      for (const e of s.event_log.slice(-10)) out(`  ${new Date(e.at).toISOString()} ${e.type.padEnd(18)} ${e.outcome.padEnd(9)} ${e.reason}`);
      return 0;
    }
    default:
      out("Usage: whiteflow-sandbox init | pay <ref> [--amount] [--scenario] | approve <apr_…> | reject <apr_…> | reconcile | status");
      return command ? 1 : 0;
  }
}
var entry = process.argv[1] ?? "";
if (/sandbox-cli\.(m?js|ts)$|sandbox[\\/]cli\.ts$/.test(entry)) {
  try {
    process.exitCode = run(process.argv.slice(2), process.env, (line) => process.stdout.write(`${line}
`));
  } catch (error) {
    process.stderr.write(`whiteflow-sandbox: ${error instanceof Error ? error.message : String(error)}
`);
    process.exitCode = 1;
  }
}
export {
  run
};
